---
navigation:
  title: "Comidas e Bebidas"
  icon: auroral:hot_cocoa
  parent: index.md
  position: 70
---

# <Color id="gold">Comidas e Bebidas</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hot_cocoa" scale="2" />

  Itens essenciais de bioma frio preparados no <ItemLink id="cold_brewing_stand" /> e fabricados com ingredientes tocados pela geada. Cada um compra tempo, calor ou uma pequena vantagem contra o frio.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Receitas</Color>
</Column>

* <ItemImage id="hot_cocoa" scale="0.75"/> [Chocolate Quente](hot_cocoa.md) — bebida quente com breve resistência à geada
* <ItemImage id="frosted_cookies" scale="0.75"/> [Biscoitos Glaciados](frosted_cookies.md) — um doce com um cintilar mágico
* <ItemImage id="roasted_snowball" scale="0.75"/> [Bola de Neve Assada](roasted_snowball.md) — uma bola de neve tostada, profundamente ofensiva aos Náutilos
* <ItemImage id="sugared_roasted_snowball" scale="0.75"/> [Bola de Neve Assada Açucarada](sugared_roasted_snowball.md) — o pedido de desculpas que um Náutilo aceita
* <ItemImage id="snore" scale="0.75"/> [S'nore](snore.md) — dois biscoitos e uma bola de neve açucarada; concede Poder do Condutor

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Da Horta</Color>
</Column>

* <ItemImage id="glow_leek" scale="0.75"/> [Alho-Poró Brilhante](../flora/glow_leeks.md) — vegetal bioluminescente cultivado em Gelo Cintilante
* <ItemImage id="candied_glow_leek" scale="0.75"/> [Alho-Poró Brilhante Confeitado](../flora/glow_leeks.md) — adoçado, sem o efeito brilhante posterior
