---
navigation:
    title: Supercélula de Armazenamento
    parent: aeadditions.md
item_ids:
  - ae2additions:super_cell_65m
  - ae2additions:super_cell_16m
  - ae2additions:super_cell_4096k
  - ae2additions:super_cell_1024k
  - ae2additions:super_cell_256k
  - ae2additions:super_cell_64k
  - ae2additions:super_cell_16k
  - ae2additions:super_cell_4k
  - ae2additions:super_cell_1k
  - ae2additions:super_cell_component_65m
  - ae2additions:super_cell_component_16m
  - ae2additions:super_cell_component_4096k
  - ae2additions:super_cell_component_1024k
  - ae2additions:super_cell_component_256k
  - ae2additions:super_cell_component_64k
  - ae2additions:super_cell_component_16k
  - ae2additions:super_cell_component_4k
  - ae2additions:super_cell_component_1k
---
# Supercélula de Armazenamento

A Supercélula de Armazenamento é uma célula muito poderosa, que permite armazenar fluidos, itens, químicos etc. na mesma célula. Você não precisa mais de uma célula para fluidos, uma célula para itens e assim por diante.

<Row>
![Terminal](assets/super_storage_cell/example_terminal.png)
![Gabinete](assets/super_storage_cell/example_drive.png)
</Row>

# Receitas
<Row>
  <RecipesFor id="ae2additions:super_cell_component_65m"/>
  <RecipesFor id="ae2additions:super_cell_65m"/>
</Row>

<Row>
  <RecipesFor id="ae2additions:super_cell_component_16m"/>
  <RecipesFor id="ae2additions:super_cell_16m"/>
</Row>

<Row>
  <RecipesFor id="ae2additions:super_cell_component_4096k"/>
  <RecipesFor id="ae2additions:super_cell_4096k"/>
</Row>

<Row>
  <RecipesFor id="ae2additions:super_cell_component_1024k"/>
  <RecipesFor id="ae2additions:super_cell_1024k"/>
</Row>

<Row>
  <RecipesFor id="ae2additions:super_cell_component_256k"/>
  <RecipesFor id="ae2additions:super_cell_256k"/>
</Row>

<Row>
  <RecipesFor id="ae2additions:super_cell_component_64k"/>
  <RecipesFor id="ae2additions:super_cell_64k"/>
</Row>

<Row>
  <RecipesFor id="ae2additions:super_cell_component_16k"/>
  <RecipesFor id="ae2additions:super_cell_16k"/>
</Row>

<Row>
  <RecipesFor id="ae2additions:super_cell_component_4k"/>
  <RecipesFor id="ae2additions:super_cell_4k"/>
</Row>

<Row>
  <RecipesFor id="ae2additions:super_cell_component_1k"/>
  <RecipesFor id="ae2additions:super_cell_1k"/>
</Row>
