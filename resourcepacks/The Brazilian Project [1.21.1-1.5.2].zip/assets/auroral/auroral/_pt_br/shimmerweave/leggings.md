---
item_ids:
  - auroral:shimmerweave_leggings
navigation:
  title: Calças de Trama Cintilante
  icon: auroral:shimmerweave_leggings
  parent: index.md
  position: 53
---

# <Color id="gold">Calças de Trama Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_leggings" scale="2" />

  Calças de mobilidade — rápidas na neve, rápidas na areia das almas. O Nether e as planícies nevadas saem do seu caminho.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_leggings" />

Aprimore umas Calças de Ferro numa Mesa de Ferraria usando um Molde de Aprimoramento de Aço Cintilante e <ItemLink id="shimmerweave_fabric" />.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Velocidade na Neve</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_leggings" />
  ### <Color id="aqua">Livre do Arrasto da Neve</Color>
</Row>

* Bônus de velocidade ao andar sobre blocos de neve.
* Sem lentidão por camadas de neve.
* Perfeito para atravessar biomas nevados.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Velocidade das Almas</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_leggings" />
  ### <Color id="aqua">Maestria da Areia das Almas</Color>
</Row>

* Efeito de Velocidade das Almas embutido em areia das almas e terra das almas.
* **Não** danifica as calças, diferente do encantamento.
* Atravesse os vales de areia das almas do Nether sem perder o ritmo.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Combine com <ItemLink id="shimmerweave_skates" /> para mobilidade máxima.
* O efeito de velocidade-das-almas acumula com o encantamento vanilla de Velocidade das Almas.
* Ótimo tanto para biomas de neve da Superfície quanto para vales de areia das almas do Nether.
