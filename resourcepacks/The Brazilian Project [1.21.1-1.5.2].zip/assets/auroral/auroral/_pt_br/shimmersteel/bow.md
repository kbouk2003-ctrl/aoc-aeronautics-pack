---
item_ids:
  - auroral:shimmersteel_bow
navigation:
  title: Arco de Aço Cintilante
  icon: auroral:shimmersteel_bow
  parent: index.md
  position: 44
---

# <Color id="gold">Arco de Aço Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_bow" scale="2" />

  Uma arma à distância que transforma bolas de neve comuns em Disparos Estelares devastadores — brilhantes, cegantes e inesgotáveis num bioma frio.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<Recipe id="auroral:shimmersteel_bow_smithing" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Disparos Estelares</Color>
</Column>

O Arco de Aço Cintilante usa **bolas de neve** como munição. Cada disparo transforma a bola de neve num Disparo Estelar.

<Row>
  <ItemImage id="shimmersteel_bow" />
  ### <Color id="aqua">Propriedades</Color>
</Row>

* **Dano** — dano base maior que flechas
* **Clarão** — inimigos perto do impacto ficam brevemente cegos e desorientados
* **Rastro de Luz** — rastro de partículas visível no ar
* **Sem Recuperação** — Disparos Estelares não podem ser recuperados após o disparo

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Bolas de neve são abundantes em biomas frios — munição raramente é problema.
* O clarão é excelente para controle de grupo em multidões densas.
* Repara-se sozinho durante auroras, como todo equipamento de Aço Cintilante.
