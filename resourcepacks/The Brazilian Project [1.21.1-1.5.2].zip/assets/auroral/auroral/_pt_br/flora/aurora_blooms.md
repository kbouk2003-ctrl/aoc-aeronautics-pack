---
item_ids:
  - auroral:aurora_bloom
  - auroral:aurora_bloom_decorative
  - auroral:frozen_petals
navigation:
  title: Flores da Aurora
  icon: auroral:frozen_petals
  parent: index.md
  position: 30
---

# <Color id="gold">Flores da Aurora</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aurora_bloom" scale="2" />

  Flores mágicas que surgem espontaneamente na neve durante auroras. A fonte das <ItemLink id="frozen_petals" /> e a porta de entrada para a maior parte do conteúdo do mod.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Encontrando Flores da Aurora</Color>
</Column>

Durante uma aurora, Flores da Aurora surgem naturalmente em superfícies de biomas frios. Elas crescem por **quatro estágios** antes de ficarem totalmente maduras. Quaisquer flores deixadas para trás quando a aurora termina murcham ao nascer do sol.

Superfícies válidas para surgimento e sobrevivência:

* Camadas de neve (desde que o bloco embaixo seja uma superfície nevada válida, para que as flores não fiquem presas em terra ou pedra se a neve derreter)
* Blocos de neve
* Neve fofa (veja abaixo)
* Gelo, Gelo Compactado e Gelo Azul (superfícies de oceano congelado funcionam)
* <ItemLink id="shimmering_ice" />

<Row>
  <ItemImage id="aurora_bloom" />
  ### <Color id="aqua">Flores na Neve</Color>
</Row>

Quando uma flor é colocada numa **camada de neve** ou surge em **neve fofa**, o tipo de neve é lembrado. Quebrar ou murchar a flor restaura a neve original no lugar — uma camada de neve volta como camada de neve, neve fofa volta como neve fofa. Flores enterradas emitem um leve rastro de partículas de floco de neve acima delas para que ainda possam ser localizadas se mais neve se acumular por cima.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Colhendo</Color>
</Column>

Quebrar uma Flor da Aurora totalmente crescida (estágio 3) derruba:

* <ItemLink id="frozen_petals" /> (1–4 com Fortuna)
* A **Flor da Aurora viva** em si, para que você possa replantá-la
* Uma **chance de 15%** de uma flor viva adicional

Quebrar uma flor imatura não produz nada — a paciência é recompensada.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Flores Preservadas (Toque Suave)</Color>
</Column>

Uma ferramenta com **Toque Suave** numa Flor da Aurora totalmente crescida produz uma **Flor da Aurora decorativa** em vez de Pétalas Congeladas. A variante decorativa:

* Nunca decai ao nascer do sol — fica para sempre
* Sempre mostra a aparência do estágio 3
* Cabe num **Vaso de Flor** para exibição
* Derruba a si mesma ao ser quebrada, podendo ser clonada em qualquer lugar

Esta é a única forma de manter uma Flor da Aurora fora de uma aurora ativa.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Usos das Pétalas Congeladas</Color>
</Column>

* **Poções Estranhas** — prepare como Vara do Nether a partir de uma Garrafa de Água em qualquer suporte de poções
* <ItemLink id="cold_brewing_stand" /> — combinadas com Lingotes de Aço Cintilante
* <ItemLink id="glow_leek_seeds" /> — combinadas com sementes de trigo
* <ItemLink id="frosted_cookies" /> — doce gostoso com um cintilar mágico
* <ItemLink id="aurora_shard" /> — infunda numa Bacia Glacial com 1 nível de aura

<RecipeFor id="glow_leek_seeds" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Transformação do Ender</Color>
</Column>

<Row>
  <ItemImage id="aurora_ender_shard" />
  ### <Color id="aqua">Botão direito com uma Pérola de Ender</Color>
</Row>

Clicar com o botão direito numa Flor da Aurora com uma **Pérola de Ender** a transforma numa <ItemLink id="ender_bloom" /> no mesmo estágio de crescimento. A pérola é consumida no processo. Veja [Flores de Ender](ender_bloom.md) para o ciclo de vida completo.
