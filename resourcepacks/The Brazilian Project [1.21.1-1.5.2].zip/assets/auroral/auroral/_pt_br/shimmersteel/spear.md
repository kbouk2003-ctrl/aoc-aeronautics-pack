---
item_ids:
  - auroral:shimmer_spear
navigation:
  title: Lança Cintilante
  icon: auroral:shimmer_spear
  parent: index.md
  position: 45
---

# <Color id="gold">Lança Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmer_spear" scale="2" />

  Uma lança perfurante de longo alcance que recompensa golpes comprometidos. Cada acerto aplica Geladura. Durante uma aurora, cada acerto pega mais pesado.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmer_spear" />

Fabricada a partir de um <ItemLink id="shimmersteel_ingot" /> e dois gravetos.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Combate com a Lança</Color>
</Column>

<Row>
  <ItemImage id="shimmer_spear" />
  ### <Color id="aqua">Alcance &amp; Carga</Color>
</Row>

* Alcance estendido para golpear de mais longe.
* Uma estocada pode atingir múltiplos alvos na sua linha de visão.
* Segure a lança na mão principal, clique com o botão direito para carregar, depois solte para estocar.
* Ataques com o botão esquerdo exigem cooldown de ataque totalmente recuperado.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Geladura ao Atingir</Color>
</Column>

Cada golpe certeiro aplica Geladura ao alvo. A Geladura desacelera o movimento, reduz cura e armadura, e faz escudos perderem durabilidade mais rápido. Golpes seguintes renovam sua duração.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aprimoramento da Aurora</Color>
</Column>

* Durante auroras, cada estocada causa dano adicional.
* A Geladura potencializada pela aurora dura o dobro com força maior.
* Partículas de aurora saem dos impactos.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Use o alcance para atingir vários inimigos alinhados à sua frente. Blocos sólidos param a estocada.
* Solte uma estocada de botão direito após pelo menos cinco tiques de carga; ela atinge força total após quinze tiques.
* Combina bem com <ItemLink id="shimmerweave_skates" /> para kitando no gelo.
* Uma aurora no céu é uma ótima janela para encarar lutas mais difíceis.
