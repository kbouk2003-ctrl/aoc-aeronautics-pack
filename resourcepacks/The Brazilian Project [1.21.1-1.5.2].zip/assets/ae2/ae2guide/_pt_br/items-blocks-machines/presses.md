---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Prensas
  icon: silicon_press
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:silicon_press
- ae2:logic_processor_press
- ae2:calculation_processor_press
- ae2:engineering_processor_press
- ae2:name_press
---

# Prensas

Há 5 prensas diferentes usadas no <ItemLink id="inscriber" />.

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

<ItemImage id="name_press" scale="4" />

## Prensas de Processador

As prensas de Silício, Lógica, Cálculo e Engenharia são usadas na produção de [processadores](processors.md).
Estas 4 prensas são obtidas quebrando um <ItemLink id="mysterious_cube" /> num [meteorito](../ae2-mechanics/meteorites.md).
Elas também podem ser duplicadas num <ItemLink id="inscriber" />.

<Column>
  <Row>
    <RecipeFor id="silicon_press" />

    <RecipeFor id="logic_processor_press" />
  </Row>

  <Row>
    <RecipeFor id="calculation_processor_press" />

    <RecipeFor id="engineering_processor_press" />
  </Row>
</Column>

## Prensa de Nome

A Prensa de Nome pode ser usada num inscritor para nomear itens, parecido com uma bigorna.

Para fabricar, clique com o botão direito na <ItemLink id="certus_quartz_cutting_knife" /> ou <ItemLink id="nether_quartz_cutting_knife" />
e insira um lingote de metal; você terá então que digitar o nome que deseja
escrever na placa e simplesmente extrair a placa pronta. Você pode usar uma ou duas placas por vez no inscritor;
se usar duas placas, ele imprimirá o nome usando a combinação dos dois nomes — espaço de cima, depois espaço de baixo.
