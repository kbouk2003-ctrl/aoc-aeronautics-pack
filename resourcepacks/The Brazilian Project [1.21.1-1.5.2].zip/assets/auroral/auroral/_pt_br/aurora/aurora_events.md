---
item_ids:
  - auroral:aurora_shard
navigation:
  title: Eventos da Aurora
  icon: auroral:aurora_shard
  parent: index.md
  position: 20
---

# <Color id="gold">Eventos da Aurora</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aurora_shard" scale="2" />

  O fenômeno celestial no coração do Auroral. Quando as luzes surgem, os biomas frios despertam.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Quando as Auroras Ocorrem</Color>
</Column>

Auroras têm **33% de chance** de começar a cada noite em biomas frios. Enquanto uma está ativa:

* O céu se enche de faixas de luz verde e rosa.
* A noite nunca fica totalmente escura.
* Os efeitos mágicos do mod são ativados.

<Row>
  ### <Color id="aqua">Configurações Pessoais</Color>
</Row>

Abra **Mods > Auroral > Config > Client** para escolher seus efeitos:

* **Efeito da Aurora no Céu** controla as faixas no céu.
* **Sons da Aurora** controla a música e os sons de início/fim.

Você pode desativar cada configuração independentemente. Essas escolhas valem só para você e não mudam a jogabilidade da aurora.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Efeitos</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">Aura Líquida</Color>
</Row>

<ItemLink id="glacial_basin" />s expostas ao céu se enchem lentamente de Aura Líquida, a substância mágica necessária para a infusão de Aço Cintilante.

<Row>
  <ItemImage id="shimmersteel_pickaxe" />
  ### <Color id="aqua">Reparo de Equipamentos</Color>
</Row>

Ferramentas de Aço Cintilante e armaduras de Trama Cintilante se reparam enquanto equipadas durante uma aurora.

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">Geração de Criaturas</Color>
</Row>

Náutilos Aurorais flutuam até perto dos jogadores durante eventos de aurora.

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">Crescimento de Flora</Color>
</Row>

<ItemLink id="aurora_bloom" />s aparecem em blocos de neve, prontas para serem colhidas por Pétalas Congeladas.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Catalisador da Aurora</Color>
</Column>

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">Tronco de Madeira do Lar</Color>
</Row>

Um <ItemLink id="hearthwood_log" /> aceso num raio de 32 blocos de um jogador num bioma frio adiciona **+15% de chance de aurora** ao anoitecer. Até três troncos acumulam para **+45%**, elevando a chance noturna a cerca de **78%** nas configurações padrão.

O catalisador é um forte impulso, não uma garantia. Para auroras quase certas, mantenha vários troncos acesos perto de onde você dorme e certifique-se de estar num bioma frio quando a noite começar.

<RecipeFor id="hearthwood_log" />

Um Tronco de Madeira do Lar aceso também concede Imunidade à Geladura, repele Fantasmas e melhora as trocas dos aldeões.
