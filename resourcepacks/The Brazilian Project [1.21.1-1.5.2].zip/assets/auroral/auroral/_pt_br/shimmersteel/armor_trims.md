---
navigation:
  title: Ornamentos de Armadura
  icon: auroral:shimmersteel_ingot
  parent: index.md
  position: 46
---

# <Color id="gold">Ornamentos de Armadura de Aço Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_ingot" scale="2" />

  Use um Lingote de Aço Cintilante como material de ornamento para dar a qualquer armadura um detalhe azul-gelado que lembra a própria aurora.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aplicando o Ornamento</Color>
</Column>

1. Obtenha um **Molde de Ferraria** (qualquer padrão de ornamento de armadura de estruturas vanilla).
2. Coloque o molde, sua peça de armadura e um <ItemLink id="shimmersteel_ingot" /> numa Mesa de Ferraria.
3. A armadura resultante ganha um ornamento azul-gelado que cintila entre azul e prata.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aparência</Color>
</Column>

O ornamento de Aço Cintilante tem um gradiente gelado distinto:

* Sombras de azul profundo
* Tons médios de azul-aço frio
* Realces de branco-gelo brilhante

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Compatibilidade</Color>
</Column>

Ornamentos de Aço Cintilante funcionam com:

* Todos os tipos de armadura vanilla — couro, malha, ferro, ouro, diamante, netherita
* A maioria das armaduras de mods que suportam o sistema de ornamentos vanilla
* Todos os padrões de ornamento vanilla — Costa, Duna, Olho, Hóspede, Criador, Costela, Sentinela, Moldador, Silêncio, Focinho, Pináculo, Maré, Vex, Proteção, Guia, Selvagem

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Combina especialmente bem com armaduras de diamante e ferro para um tema frio coeso.
* Combine com a armadura de Trama Cintilante para o visual completo de aventureiro congelado.
* A alta encantabilidade do Aço Cintilante significa que a armadura ornamentada ainda encanta lindamente.
