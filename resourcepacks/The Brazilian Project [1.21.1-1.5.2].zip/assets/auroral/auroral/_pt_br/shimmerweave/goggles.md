---
item_ids:
  - auroral:shimmerweave_goggles
navigation:
  title: Óculos de Trama Cintilante
  icon: auroral:shimmerweave_goggles
  parent: index.md
  position: 51
---

# <Color id="gold">Óculos de Trama Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_goggles" scale="2" />

  Óculos encantados que revelam ameaças ocultas na escuridão. Criaturas hostis brilham através das paredes.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_goggles" />

Aprimore um Capacete de Ferro numa Mesa de Ferraria usando um Molde de Aprimoramento de Aço Cintilante e <ItemLink id="shimmerweave_fabric" />.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Detecção de Hostis</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_goggles" />
  ### <Color id="aqua">Aura Brilhante</Color>
</Row>

* **Brilho** — todas as criaturas hostis num raio de 32 blocos brilham, visíveis através de paredes.
* Perfeito para exploração de cavernas e ataques noturnos.
* Funciona em escuridão total.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Combine com poções de Visão Noturna ou <ItemLink id="glow_leek" />s para visibilidade total.
* Essencial para explorar cavernas escuras com segurança.
* O raio de 32 blocos cobre a maioria das situações de combate.
