---
item_ids:
  - auroral:ender_bloom
  - auroral:aurora_ender_shard
navigation:
  title: Flores de Ender
  icon: auroral:aurora_ender_shard
  parent: index.md
  position: 33
---

# <Color id="gold">Flores de Ender</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="ender_bloom" scale="2" />

  As primas tocadas pelo ender das Flores da Aurora — roxas, inquietas e uma fonte renovável de Pérolas de Ender.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Criação</Color>
</Column>

Flores de Ender nunca surgem sozinhas. Para fazer uma:

1. Encontre ou cultive uma <ItemLink id="aurora_bloom" /> durante um evento de aurora.
2. Clique com o botão direito na flor segurando uma **Pérola de Ender**.
3. A flor se transforma numa Flor de Ender no mesmo estágio de crescimento. A pérola é consumida.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Persistência</Color>
</Column>

Diferente das Flores da Aurora, as Flores de Ender **persistem para sempre**. Elas não murcham ao nascer do sol e permanecem quando a aurora termina.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Requisitos de Crescimento</Color>
</Column>

Uma Flor de Ender só avança pelos estágios de crescimento quando plantada em:

* <ItemLink id="shimmer_soil" />
* **Pedra do End**

Em qualquer outro bloco de suporte ela sobrevive indefinidamente, mas fica no estágio em que foi plantada. Adubo ósseo também é ineficaz a menos que plantada num dos blocos acima.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Colhendo</Color>
</Column>

Quebrar uma Flor de Ender em **qualquer** estágio derruba um único item de Flor de Ender (que sempre replanta no estágio 0).

Quando quebrada no estágio 3, ela **também** derruba:

* Um <ItemLink id="aurora_ender_shard" />
* Uma **chance de 5%** de uma Flor de Ender adicional

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Fragmentos da Aurora do Ender</Color>
</Column>

<Row>
  <ItemImage id="aurora_ender_shard" />
  ### <Color id="aqua">Pérolas de Ender Renováveis</Color>
</Row>

Dois Fragmentos da Aurora do Ender se fabricam de volta numa Pérola de Ender. Uma fazenda madura de Flores de Ender se torna uma fonte renovável de Pérolas de Ender.

<Recipe id="auroral:ender_pearl_from_shards" />
