---
item_ids:
  - auroral:frosted_cookies
navigation:
  title: Biscoitos Glaciados
  icon: auroral:frosted_cookies
  parent: food/index.md
  position: 2
---

# <Color id="gold">Biscoitos Glaciados</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="frosted_cookies" scale="2" />

  Doces polvilhados com Pétalas Congeladas mágicas, cintilando como neve fresca sob a luz da aurora.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="frosted_cookies" />

(Faz 4 Biscoitos Glaciados)

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Propriedades</Color>
</Column>

* **Lanche Rápido** — restaura uma pequena quantidade de fome
* **Partículas Cintilantes** — comer produz partículas brilhantes de aurora
* **Empilhável** — empilha até 64

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Ótimo para restaurar fome rapidamente em movimento.
* Receita eficiente — uma Pétala Congelada faz 4 biscoitos.
* Companhia perfeita para o <ItemLink id="hot_cocoa" /> em noites frias.
