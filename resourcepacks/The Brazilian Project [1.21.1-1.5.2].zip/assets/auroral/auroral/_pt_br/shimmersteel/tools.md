---
item_ids:
  - auroral:shimmersteel_pickaxe
  - auroral:shimmersteel_axe
  - auroral:shimmersteel_shovel
  - auroral:shimmersteel_sword
  - auroral:shimmersteel_hoe
  - auroral:shimmer_soil
navigation:
  title: Ferramentas de Aço Cintilante
  icon: auroral:shimmersteel_pickaxe
  parent: index.md
  position: 43
---

# <Color id="gold">Ferramentas de Aço Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_pickaxe" scale="2" />

  Levemente melhores que ferro, alta encantabilidade e uma habilidade especial única por ferramenta. Todas as cinco se reparam sozinhas enquanto seguradas durante uma aurora.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Picareta</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_pickaxe" />
  ### <Color id="aqua">Fortuna Inerente para Gemas</Color>
</Row>

* Aplica automaticamente **Fortuna III** a minérios de diamante, esmeralda, lápis-lazúli e outras gemas.
* A chance normal de Fortuna se aplica a todo o resto.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Machado</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_axe" />
  ### <Color id="aqua">Forçar Oxidação</Color>
</Row>

* Clique com o botão direito em qualquer bloco de cobre para avançar instantaneamente seu estado de oxidação.
* Despenca troncos, raspa cobre e remove cera como um machado comum.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Pá</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_shovel" />
  ### <Color id="aqua">Toque Suave Inerente</Color>
</Row>

* Sempre colhe blocos como se Toque Suave estivesse aplicado.
* Perfeita para coletar camadas de neve, blocos de grama e mais.
* Ainda cria caminhos de terra e apaga fogueiras.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Espada</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_sword" />
  ### <Color id="aqua">Lentidão, Execução, Marca de Neve</Color>
</Row>

* **Lentidão I** — cada golpe a aplica ao alvo.
* **Execução** — causa dano bônus massivo a inimigos com menos de 15% de vida.
* **Marca de Neve** — coloca uma camada de neve onde inimigos executados caem.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Enxada</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_hoe" />
  ### <Color id="aqua">Toque Suave &amp; Criação de Solo Cintilante</Color>
</Row>

* **Toque Suave Inerente** — colhe plantações e blocos como se Toque Suave estivesse aplicado.
* **Criação de Solo Cintilante** — clique com o botão direito em blocos de neve, neve fofa, terra, grama ou camadas de neve para criar <ItemLink id="shimmer_soil" />.
* **Melhoria de Terra Arada** — clique com o botão direito em terra arada comum para aprimorá-la (umidade preservada).
* Perfeita para começar fazendas em biomas congelados sem precisar de terra.

<Row>
  <ItemImage id="shimmer_soil" />
  ### <Color id="aqua">Solo Cintilante</Color>
</Row>

Esta terra arada mágica acelera o crescimento de plantações:

* **3x mais rápido** à noite
* **5x mais rápido** durante auroras
* Emite um brilho fraco (nível de luz 2)
* Hidratada por água **ou** <ItemLink id="shimmering_ice" /> num raio de 4 blocos
* Não reverte para terra enquanto houver plantações
* Aceita qualquer semente de plantação vanilla ou de mod, como terra arada comum

Combine com Gelo Cintilante para fazendas subterrâneas brilhantes que nunca precisam de água.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Auto-Reparo</Color>
</Column>

Todas as cinco ferramentas de Aço Cintilante se reparam enquanto seguradas durante uma aurora.
