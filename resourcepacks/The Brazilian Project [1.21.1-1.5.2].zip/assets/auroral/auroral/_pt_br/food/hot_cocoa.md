---
item_ids:
  - auroral:hot_cocoa
navigation:
  title: Chocolate Quente
  icon: auroral:hot_cocoa
  parent: food/index.md
  position: 1
---

# <Color id="gold">Chocolate Quente</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hot_cocoa" scale="2" />

  Uma caneca fumegante que espanta o frio e ainda te recupera ao mesmo tempo.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="hot_cocoa" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Efeitos</Color>
</Column>

* **Imunidade à Geladura** — 3 minutos, proteção total contra o efeito Geladura
* **Regeneração I** — 30 segundos
* **Restauração de Fome** — moderada

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Mantenha um estoque ao explorar biomas frios.
* A fabricação devolve o balde de leite vazio; beber restaura 4 pontos de fome.
* Combina bem com <ItemLink id="frosted_cookies" /> para uma pausa aconchegante.
