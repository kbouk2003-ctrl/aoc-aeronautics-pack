---
item_ids:
  - auroral:shimmerweave_tunic
navigation:
  title: Túnica de Trama Cintilante
  icon: auroral:shimmerweave_tunic
  parent: index.md
  position: 52
---

# <Color id="gold">Túnica de Trama Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_tunic" scale="2" />

  Um peitoral mágico que vira a chama contra si mesma. Apaga o usuário automaticamente e ignora dano de fogo.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_tunic" />

Aprimore um Peitoral de Ferro numa Mesa de Ferraria usando um Molde de Aprimoramento de Aço Cintilante e <ItemLink id="shimmerweave_fabric" />.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Auto-Extinção</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_tunic" />
  ### <Color id="aqua">Proteção Instantânea contra Fogo</Color>
</Row>

* Apaga o usuário automaticamente quando em chamas.
* Nenhum dano de fogo sofrido enquanto equipada.
* Funciona contra todas as fontes de fogo — lava, blocos de fogo, ataques de blaze.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aura Refrescante</Color>
</Column>

O tecido infundido com aurora repele o calor, tornando a túnica indispensável para:

* Exploração do Nether
* Lutar contra Blazes
* Trabalhar perto de lava

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Essencial para viagens seguras ao Nether.
* Combina bem com <ItemLink id="shimmerweave_skates" />, que convertem lava em obsidiana ao contato.
* A proteção contra fogo é passiva — não precisa de ativação.
